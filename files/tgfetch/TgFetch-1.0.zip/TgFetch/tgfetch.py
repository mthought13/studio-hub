#!/usr/bin/env python3
"""tgfetch — download files from Telegram chats / forum topics. Read-only: never sends anything.

  tgfetch chats [QUERY]                               list chats matching QUERY
  tgfetch topics CHAT                                 list forum topics of a chat
  tgfetch people CHAT [--topic T]                     who sent files recently
  tgfetch list CHAT [--topic T] [--from NAME] [--last N]           preview, no download
  tgfetch get  CHAT [--topic T] [--from NAME] [--last N] --to DIR [--tray]

Names of chats, topics and people are matched loosely: case, ё/е, Cyrillic/Latin, partial words
("Маша" finds "Мария Петрова" and "Masha"). Aliases: ~/.config/telegram/people.json {"маша": 123456789}.
Exit codes: 0 ok · 2 nothing found · 3 ambiguous (candidates printed) · 4 not logged in.
"""
import argparse, asyncio, datetime, difflib, json, os, re, subprocess, sys

from telethon import TelegramClient, functions, types, utils

try:  # download progress in RefTray (optional)
    sys.path.insert(0, os.path.expanduser("~/RefTray"))
    from dl import Progress as TrayProgress
except Exception:
    TrayProgress = None

CONF = os.path.expanduser("~/.config/telegram")
API = os.path.join(CONF, "api.json")
SESSION = os.path.join(CONF, "tgfetch")
PEOPLE = os.path.join(CONF, "people.json")
LOG = os.path.expanduser("~/TgFetch/downloads.log")
REFTRAY = os.path.expanduser("~/RefTray/reftray.py")

TRANSLIT = dict(zip("абвгдеёжзийклмнопрстуфхцчшщъыьэюя",
                    ["a", "b", "v", "g", "d", "e", "e", "zh", "z", "i", "y", "k", "l", "m", "n", "o", "p",
                     "r", "s", "t", "u", "f", "h", "ts", "ch", "sh", "sch", "", "y", "", "e", "yu", "ya"]))


def die(code, msg):
    print(msg)
    sys.exit(code)


def norm(s):
    s = (s or "").casefold().replace("ё", "е")
    return re.sub(r"[\W_]+", " ", s).strip()


def translit(s):
    return "".join(TRANSLIT.get(ch, ch) for ch in s)


def forms(s):
    n = norm(s)
    return {n, translit(n)}


def compact(s):
    return s.replace(" ", "")


def title_candidates(query, items, key):
    """Best matches of query among items by title: exact → substring → fuzzy."""
    same = [i for i in items if compact(norm(key(i))) == compact(norm(query))]
    if same:   # exact in the same script wins over a transliterated twin ("Prod" vs "Прод")
        return same
    qs = {compact(f) for f in forms(query)}
    keyed = [(i, {compact(f) for f in forms(key(i))}) for i in items]
    exact = [i for i, ks in keyed if qs & ks]
    if exact:
        return exact
    sub = [i for i, ks in keyed if any(q and (q in k or (k and k in q)) for q in qs for k in ks)]
    if sub:
        return sub
    scored = sorted(((max(difflib.SequenceMatcher(None, q, k).ratio() for q in qs for k in ks), i)
                     for i, ks in keyed if ks), key=lambda t: -t[0])
    if not scored or scored[0][0] < 0.5:
        return []
    if len(scored) == 1 or scored[0][0] - scored[1][0] >= 0.1:
        return [scored[0][1]]
    return [i for r, i in scored if r >= scored[0][0] - 0.1][:5]


def person_matches(query, *names):
    for q in forms(query):
        for n in names:
            for nf in forms(n):
                if not nf:
                    continue
                if q in nf:
                    return True
                for w in nf.split():
                    for x in q.split():
                        if len(w) >= 3 and len(x) >= 3 and (x.startswith(w) or w.startswith(x)):
                            return True
    return False


def safe(name):
    return re.sub(r'[/:\\\x00-\x1f]', "_", name).strip() or "file"


def human(n):
    for unit in ("Б", "КБ", "МБ", "ГБ"):
        if n < 1024 or unit == "ГБ":
            return f"{n:.0f} {unit}" if unit == "Б" else f"{n:.1f} {unit}"
        n /= 1024


async def open_client():
    if not (os.path.exists(API) and os.path.exists(SESSION + ".session")):
        die(4, "Вход в Telegram не выполнен. Пусть пользователь запустит ~/TgFetch/login.sh")
    api = json.load(open(API))
    c = TelegramClient(SESSION, api["api_id"], api["api_hash"],
                       device_model="Studio Fetch (Mac)", app_version="1.0")
    await c.connect()
    if not await c.is_user_authorized():
        die(4, "Сессия Telegram недействительна. Пусть пользователь заново запустит ~/TgFetch/login.sh")
    return c


async def find_chat(c, query, want_forum=False):
    dialogs = [d async for d in c.iter_dialogs(limit=1000)]
    found = title_candidates(query, dialogs, lambda d: d.name)
    if not found:
        die(2, f"Чат «{query}» не найден.")
    if len(found) > 1 and want_forum:   # a topic was asked for → only groups with topics
        forums = [d for d in found if getattr(d.entity, "forum", False)]
        found = forums or found
    if len(found) > 1:
        die(3, "Несколько подходящих чатов:\n" + "\n".join(f"  {d.name}  (id {d.id})" for d in found))
    return found[0]


async def get_topics(c, entity):
    if not getattr(entity, "forum", False):
        return []
    res = await c(functions.messages.GetForumTopicsRequest(peer=entity, offset_date=None, offset_id=0,
                                                           offset_topic=0, limit=100))
    return [t for t in res.topics if isinstance(t, types.ForumTopic)]


async def find_topic(c, entity, query):
    if not query:
        return None
    topics = await get_topics(c, entity)
    if not topics:
        die(2, "В этом чате нет топиков.")
    found = title_candidates(query, topics, lambda t: t.title)
    if not found:
        die(2, f"Топик «{query}» не найден. Есть: " + ", ".join(t.title for t in topics))
    if len(found) > 1:
        die(3, "Несколько подходящих топиков:\n" + "\n".join(f"  {t.title}" for t in found))
    return found[0]


async def media_messages(c, entity, topic, scan):
    if topic is None:
        it = c.iter_messages(entity, limit=scan)
    elif topic.id == 1:   # "General" has no thread of its own
        it = c.iter_messages(entity, limit=scan * 3)
    else:
        it = c.iter_messages(entity, limit=scan, reply_to=topic.id)
    async for m in it:
        if topic is not None and topic.id == 1 and m.reply_to and m.reply_to.forum_topic:
            continue
        if not m.file or isinstance(m.media, types.MessageMediaWebPage) or m.sticker:
            continue
        yield m


def load_people():
    try:
        return {norm(k): v for k, v in json.load(open(PEOPLE)).items()}
    except (OSError, ValueError):
        return {}


async def collect(c, args):
    dialog = await find_chat(c, args.chat, want_forum=bool(args.topic))
    entity = dialog.entity
    topic = await find_topic(c, entity, args.topic)
    alias = load_people().get(norm(args.sender)) if args.sender else None
    picked, senders = [], {}
    async for m in media_messages(c, entity, topic, args.scan):
        s = await m.get_sender()
        name = utils.get_display_name(s) if s else "?"
        username = getattr(s, "username", None) or ""
        if args.sender:
            if isinstance(alias, int):
                if m.sender_id != alias:
                    continue
            elif not person_matches(alias or args.sender, name, username):
                continue
        senders[m.sender_id] = f"{name} (@{username})" if username else name
        picked.append((m, name))
        if args.sender and len(senders) > 1:
            break
        if len(picked) >= args.last:
            break
    if args.sender and len(senders) > 1:
        die(3, f"«{args.sender}» подходит нескольким людям — уточни или добавь псевдоним в {PEOPLE}:\n"
            + "\n".join(f"  {n}  (id {i})" for i, n in senders.items()))
    if not picked:
        where = f"«{dialog.name}»" + (f" / «{topic.title}»" if topic else "")
        die(2, f"В {where} не найдено файлов" + (f" от «{args.sender}»" if args.sender else "")
            + f" среди последних {args.scan} сообщений.")
    picked.reverse()  # oldest first
    return dialog, topic, picked


def describe(m):
    f = m.file
    kind = "фото (сжатое Telegram)" if m.photo else (f.mime_type or "файл")
    return f"{f.name or '—'} · {kind} · {human(f.size or 0)}"


def target_path(folder, m, sender):
    name = m.file.name
    if not name:
        ext = m.file.ext or ""
        ext = ".jpg" if ext in (".jpe", ".jpeg") else ext
        name = f"{m.date.astimezone():%Y-%m-%d_%H-%M}_{safe(sender)}_{m.id}{ext}"
    path = os.path.join(folder, safe(name))
    if os.path.exists(path) and os.path.getsize(path) != (m.file.size or -1):
        root, ext = os.path.splitext(path)
        path = f"{root}_{m.id}{ext}"
    return path


def progress(label):
    state = {"last": -1}

    def cb(done, total):
        if total:
            pct = int(done * 100 / total) // 20 * 20
            if pct != state["last"]:
                state["last"] = pct
                print(f"    {label}: {pct}%", file=sys.stderr, flush=True)
    return cb


async def cmd_get(c, args):
    dialog, topic, picked = await collect(c, args)
    folder = os.path.expanduser(args.to)
    os.makedirs(folder, exist_ok=True)
    saved = []
    for m, sender in picked:
        path = target_path(folder, m, sender)
        if os.path.exists(path) and os.path.getsize(path) == (m.file.size or -1):
            print(f"уже есть  {path}")
        else:
            tray = TrayProgress(os.path.basename(path), m.file.size or 0) if TrayProgress else None
            printer = progress(os.path.basename(path))

            def report(done, total, printer=printer, tray=tray):
                printer(done, total)
                if tray:
                    tray.update(done, total)
            try:
                await c.download_media(m, file=path, progress_callback=report)
            except BaseException as e:
                if tray:
                    tray.fail(e)
                raise
            if tray:
                tray.done = os.path.getsize(path)
                tray.finish(path)
            print(f"скачано   {path}  ({human(os.path.getsize(path))})")
            with open(LOG, "a") as log:
                log.write(json.dumps({"at": datetime.datetime.now().isoformat(timespec="seconds"),
                                      "chat": dialog.name, "topic": topic.title if topic else None,
                                      "msg": m.id, "from": sender, "sent": m.date.isoformat(),
                                      "path": path}, ensure_ascii=False) + "\n")
        if m.photo:
            print("          ⚠ отправлено «как фото» — Telegram сжал его; оригинал только если прислать «как файл»")
        saved.append((path, m, sender))
    if args.tray and saved:
        tray = {"title": f"Telegram · {dialog.name}" + (f" / {topic.title}" if topic else ""),
                "note": "от " + ", ".join(sorted({s for _, _, s in saved})),
                "items": [{"path": p, "role": f"{s} · {m.date.astimezone():%d.%m %H:%M}",
                           **({"note": m.message[:200]} if m.message else {})} for p, m, s in saved]}
        subprocess.run([sys.executable if os.path.exists(REFTRAY) else "python3", REFTRAY, "-"],
                       input=json.dumps(tray, ensure_ascii=False), text=True)


async def cmd_list(c, args):
    dialog, topic, picked = await collect(c, args)
    print(f"«{dialog.name}»" + (f" / «{topic.title}»" if topic else ""))
    for m, sender in picked:
        cap = f" · «{m.message[:60]}»" if m.message else ""
        print(f"  {m.date.astimezone():%d.%m %H:%M}  {sender}: {describe(m)}{cap}")


async def cmd_people(c, args):
    dialog = await find_chat(c, args.chat, want_forum=bool(args.topic))
    topic = await find_topic(c, dialog.entity, args.topic)
    counts = {}
    async for m in media_messages(c, dialog.entity, topic, args.scan):
        s = await m.get_sender()
        key = (m.sender_id, utils.get_display_name(s) if s else "?", getattr(s, "username", None))
        counts[key] = counts.get(key, 0) + 1
    for (sid, name, un), n in sorted(counts.items(), key=lambda t: -t[1]):
        print(f"  {n:4d} файлов  {name}" + (f" (@{un})" if un else "") + f"  id {sid}")


async def cmd_chats(c, args):
    dialogs = [d async for d in c.iter_dialogs(limit=1000)]
    if args.query:
        dialogs = title_candidates(args.query, dialogs, lambda d: d.name) or []
    for d in dialogs[:60]:
        forum = " [топики]" if getattr(d.entity, "forum", False) else ""
        print(f"  {d.name}{forum}  (id {d.id})")


async def cmd_topics(c, args):
    dialog = await find_chat(c, args.chat, want_forum=True)
    topics = await get_topics(c, dialog.entity)
    if not topics:
        die(2, f"В «{dialog.name}» нет топиков.")
    for t in topics:
        print(f"  {t.title}  (id {t.id})")


def main():
    p = argparse.ArgumentParser(prog="tgfetch", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("chats"); s.add_argument("query", nargs="?")
    s = sub.add_parser("topics"); s.add_argument("chat")
    for name in ("people", "list", "get"):
        s = sub.add_parser(name)
        s.add_argument("chat")
        s.add_argument("--topic")
        s.add_argument("--scan", type=int, default=300, help="сколько последних сообщений просматривать")
        if name != "people":
            s.add_argument("--from", dest="sender")
            s.add_argument("--last", type=int, default=5)
        if name == "get":
            s.add_argument("--to", required=True)
            s.add_argument("--tray", action="store_true", help="сразу показать скачанное в RefTray")
    args = p.parse_args()

    async def run():
        c = await open_client()
        try:
            await {"chats": cmd_chats, "topics": cmd_topics, "people": cmd_people,
                   "list": cmd_list, "get": cmd_get}[args.cmd](c, args)
        finally:
            await c.disconnect()
    asyncio.run(run())


if __name__ == "__main__":
    main()
