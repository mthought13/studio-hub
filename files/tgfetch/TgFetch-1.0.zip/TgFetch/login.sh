#!/bin/zsh
# One-time Telegram login for tgfetch (run it yourself: you type the code / password).
exec "$HOME/TgFetch/.venv/bin/python" "$HOME/TgFetch/login.py"
