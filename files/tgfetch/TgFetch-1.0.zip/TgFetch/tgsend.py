#!/usr/bin/env python3
"""tgsend — send a file (with a caption) to a Telegram chat / forum topic as the user.

  tgsend CHAT [--topic T] --file PATH [--caption TEXT]          dry run: shows what would be sent
  tgsend CHAT [--topic T] --file PATH [--caption TEXT] --yes    really send

Only with an explicit --yes, and only after the user confirmed the exact chat, topic, file and caption.
"""
import argparse, asyncio, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from tgfetch import open_client, find_chat, find_topic, human  # noqa: E402


async def run(args):
    path = os.path.expanduser(args.file)
    if not os.path.isfile(path):
        sys.exit(f"Нет файла: {path}")
    c = await open_client()
    try:
        dialog = await find_chat(c, args.chat, want_forum=bool(args.topic))
        topic = await find_topic(c, dialog.entity, args.topic)
        where = f"«{dialog.name}»" + (f" / «{topic.title}»" if topic else "")
        print(f"Куда:    {where}")
        print(f"Файл:    {os.path.basename(path)} ({human(os.path.getsize(path))})")
        print(f"Подпись: {args.caption or '—'}")
        if not args.yes:
            print("Пробный запуск — ничего не отправлено. Добавь --yes, чтобы отправить.")
            return
        # General (id 1) has no thread of its own: a plain message lands there.
        reply_to = topic.id if topic and topic.id != 1 else None
        msg = await c.send_file(dialog.entity, path, caption=args.caption or None, reply_to=reply_to, force_document=True)
        print(f"Отправлено: сообщение {msg.id}")
    finally:
        await c.disconnect()


def main():
    p = argparse.ArgumentParser(prog="tgsend", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("chat")
    p.add_argument("--topic")
    p.add_argument("--file", required=True)
    p.add_argument("--caption", default="")
    p.add_argument("--yes", action="store_true")
    asyncio.run(run(p.parse_args()))


if __name__ == "__main__":
    main()
