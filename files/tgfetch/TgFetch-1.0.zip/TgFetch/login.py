#!/usr/bin/env python3
"""One-time Telegram login for tgfetch. Run it yourself in a terminal: ~/TgFetch/login.sh
Asks for api_id / api_hash (from my.telegram.org), phone, code and the cloud password (if set).
Everything stays in ~/.config/telegram (folder 700, files 600)."""
import asyncio, getpass, json, os, re, sys

from telethon import TelegramClient

CONF = os.path.expanduser("~/.config/telegram")
API = os.path.join(CONF, "api.json")
SESSION = os.path.join(CONF, "tgfetch")


def save_private(path, data):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(data, f)
    os.chmod(path, 0o600)


async def main():
    os.makedirs(CONF, exist_ok=True)
    os.chmod(CONF, 0o700)

    if os.path.exists(API):
        api = json.load(open(API))
        print(f"api_id уже сохранён ({api['api_id']}). Чтобы ввести заново — удали {API}")
    else:
        print("Данные со страницы my.telegram.org → API development tools")
        api_id = input("App api_id (число): ").strip()
        api_hash = input("App api_hash (вставь ⌘V и нажми Enter): ").strip()
        if not api_id.isdigit() or not re.fullmatch(r"[0-9a-fA-F]{32}", api_hash):
            sys.exit("Похоже, api_id или api_hash введены неверно. Запусти ещё раз.")
        api = {"api_id": int(api_id), "api_hash": api_hash}
        save_private(API, api)

    client = TelegramClient(SESSION, api["api_id"], api["api_hash"],
                            device_model="Studio Fetch (Mac)", app_version="1.0")
    await client.start(
        phone=lambda: input("Номер телефона (+7…): ").strip(),
        code_callback=lambda: input("Код из Telegram: ").strip(),
        password=lambda: getpass.getpass("Облачный пароль (ввод скрыт — проверь раскладку EN/RU и Caps Lock): "),
    )
    me = await client.get_me()
    await client.disconnect()
    os.chmod(SESSION + ".session", 0o600)
    print(f"\nГотово: вход выполнен как {me.first_name or ''} {me.last_name or ''} (@{me.username or '—'}).")
    print("Это окно можно закрыть и вернуться в чат с Claude.")


if __name__ == "__main__":
    asyncio.run(main())
