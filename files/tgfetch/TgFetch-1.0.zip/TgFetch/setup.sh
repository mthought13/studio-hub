#!/bin/zsh
# Installs TgFetch's Python environment into ~/TgFetch/.venv (Telethon). Safe to run again.
set -e
cd "$(dirname "$0")"
if ! /usr/bin/python3 -c 'import sys; sys.exit(sys.version_info < (3, 8))' 2>/dev/null; then
  echo "Нужен python3 (Command Line Tools). Выполни: xcode-select --install — и запусти setup.sh ещё раз."
  exit 1
fi
[ -x .venv/bin/python ] || /usr/bin/python3 -m venv .venv
.venv/bin/python -m pip install -q --upgrade pip >/dev/null 2>&1 || true
.venv/bin/python -m pip install -q "telethon==1.45.0"
chmod +x tgfetch tgsend login.sh
echo "Готово. Теперь один раз войди в Telegram: ~/TgFetch/login.sh"
